package com.yujie.client;

import com.yujie.gui.SocketFace;

public class ClientMain {
	public static void main(String[] args) {
		System.out.println("�ͻ���������");
		SocketFace socketFace = new SocketFace();
	}
}
